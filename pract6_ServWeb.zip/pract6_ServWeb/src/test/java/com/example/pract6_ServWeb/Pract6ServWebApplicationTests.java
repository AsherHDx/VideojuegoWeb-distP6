package com.example.pract6_ServWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pract6ServWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
